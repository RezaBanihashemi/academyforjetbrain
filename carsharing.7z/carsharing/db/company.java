package carsharing.db;

import java.sql.SQLException;
import java.sql.Statement;

public class company {
    public static void addcompany(String name){

    }

}
