package carsharing.db;

import java.sql.*;

public class dbCls {
    static Connection conn = null;
    static final String JDBC_DRIVER = "org.h2.Driver";
    static final String DB_URL = "jdbc:h2:file:../task/src/carsharing/db/carsharing";

    static Connection getConnection() throws ClassNotFoundException, SQLException {
        Class.forName(JDBC_DRIVER);
        conn = DriverManager.getConnection(DB_URL); //,USER,PASS);
        conn.setAutoCommit(true);
        return conn;
    }
    public static void execute(String query) throws ClassNotFoundException, SQLException{
        try {
            Statement statement = dbCls.getConnection().createStatement();
            statement.executeUpdate(query);
        }
        catch (SQLException e){
            e.printStackTrace();
        }
    }
    public static int getCarIDbyCustomerID(int ID) throws ClassNotFoundException, SQLException {


        ResultSet executeQuery = executeQuery("select RENTED_CAR_ID from customer where id = " + ID);
        int res = -1;
        while (executeQuery.next()) {
            res = executeQuery.getInt("RENTED_CAR_ID");
        }
        return res;
    }

    public static String getCarName(int ID) throws ClassNotFoundException, SQLException{


            ResultSet executeQuery= executeQuery("select NAME from car where id = " + ID);
            executeQuery.next();
            return(executeQuery.getString("NAME"));

    }

    public static int executeUpdate(String query) throws ClassNotFoundException, SQLException{
        int Res=-1;
        try {
            Statement statement = dbCls.getConnection().createStatement();
            statement.executeUpdate(query);
            Res = statement.getUpdateCount();
        }
        catch (SQLException e){
            e.printStackTrace();
        }
        finally {
            return Res;
        }
    }
    public static ResultSet executeQuery(String query){
        ResultSet result = null;
        try {
            Statement  statement = getConnection().createStatement();
            result =  statement.executeQuery(query);
        }
        catch (SQLException e){
            e.printStackTrace();
            result = null;
        }
        finally {
            return result;
        }
    }
}
